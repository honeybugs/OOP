package kr.otherpkg;

import kr.ac.kookmin.cs.*;

/**
 * @version 1.0 2022-12-01
 * @author segeon
 */
class PPointTest {
    /**
     * PPoint 클래스에 x, y값을 각각 10, 20으로 전달하여 인스턴스 생성함.
     * 전달후 PPoint 인스턴스의 x, y값 출력
     * 
     * @param args 시스템 인자 값
     */
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", " + aObj.getY());
    }
}
