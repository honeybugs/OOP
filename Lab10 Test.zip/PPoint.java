package kr.ac.kookmin.cs;

/**
 * @version 1.0 2022-12-01
 * @author segeon
 */
public class PPoint {
    int xA;
    int yA;

    /**
     * x, y 값읍 입렵받고 저장함.
     * 
     * @param x x 값
     * @param y y 값
     */
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };

    /**
     * 
     * @return X 값
     */
    public int getX() {
        return xA;
    }

    /**
     * 
     * @return Y 값
     */
    public int getY() {
        return yA;
    }
}
